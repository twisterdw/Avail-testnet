Runtime API definition required by System RPC extensions.

This API should be imported and implemented by the runtime,
of a node that wants to use the custom RPC extension
adding System access methods.

License: Apache-2.0