/**
 * Default configuration used in examples.
 */
export default {
    mnemonic: "bottom drive obey lake curtain smoke basket hold race lonely fit walk//Alice",
    ApiURL: "ws://127.0.0.1:9944",
    app_id: 0,
    amount: 10,
    receiver: "5FHneW46xGXgs5mUiveU4sbTyGBzmstUspZC92UhjJM694ty"
}
