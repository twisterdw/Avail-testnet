## Avail Rust examples

Sample examples written in Rust that demonstrate interaction with Avail network.

- Navigate to the `avail-subxt` folder.
- To run particular example e.g. [accounts_from_mnemonics.rs](accounts_from_mnemonics.rs) run the following command: 
    ```
    cargo run --example accounts_from_mnemonics
    ```